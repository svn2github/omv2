Ext.define('Desktop.model.Wallpaper', {
    extend: 'Ext.data.TreeModel',
    fields: [
        { name: 'text' },
        { name: 'img' }
    ]
});
